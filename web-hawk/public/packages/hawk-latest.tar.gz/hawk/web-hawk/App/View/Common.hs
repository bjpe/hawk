module App.View.Common 
  ( module Hawk.View.Template.HtmlHelper
  , titleT
  , mainLCR
  , mainLC
  , lHead
  , lList
  , lList'
  , cHead
  , cBody
  , rHead
  , rBody
  , divId
  , divClass
  , anchor
  ) where

import Hawk.View.Template.HtmlHelper

titleT :: String
titleT = "Hawk: Haskell Web Application Kit"

-- | Left -> Center -> Right -> Main
mainLCR :: XmlTrees -> XmlTrees -> XmlTrees -> XmlTrees
mainLCR l c r = [ divId "leftlcr" l
                , divId "rightlcr" r
                , divId "mainlcr" c
                ]
mainLC :: XmlTrees -> XmlTrees -> XmlTrees
mainLC l c = [ divId "leftlc" l
             , divId "mainlc" c
             ]

-- ------------------------------------------------------------------------------
-- formatting functions
-- ------------------------------------------------------------------------------
-- | Make a head for a short link list
lHead :: String -> XmlTrees
lHead h = [ divId "lefthead" [text h] ]

-- | Make the short link list from a [(name,url)], String defines the class and therefore the submenu layer
lList :: [(String, String)] -> String -> XmlTrees
lList l i = lList' (map anc l) i
  where anc (x,y) = (x,'#':y)

lList' :: [(String, String)] -> String -> XmlTrees
lList' l i = map sl l
  where sl (x,y) = divClass ("leftlink"++i) [link y [text x]]

cHead :: String -> String -> XmlTree
cHead h a = divClass "contenthead" [anchor a, text h]

cBody :: String -> XmlTree
cBody c = divClass "contentbody" [text c]

rHead :: String -> XmlTree
rHead h = divClass "righthead" [text h]

rBody :: String -> XmlTree
rBody c = divClass "rightbody" [text c]

-- ------------------------------------------------------------------------------
-- html functions
-- ------------------------------------------------------------------------------
divId :: String -> XmlTrees -> XmlTree
divId i = contentTag "div" [("id",i)]

divClass :: String -> XmlTrees -> XmlTree
divClass c = contentTag "div" [("class",c)]

anchor :: String -> XmlTree
anchor name = contentTag "a" [("name",name)] []
