module App.View.API where

import App.View.Common

apiL :: XmlTrees
apiL = [text ""]

apiC :: XmlTrees
apiC = [text "link to faq, link to haddock docu"]
