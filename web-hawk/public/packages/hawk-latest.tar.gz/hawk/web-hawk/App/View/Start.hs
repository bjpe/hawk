module App.View.Start where

import App.View.Common

-- ------------------------------------------------------------------------------
-- Getting Started
-- ------------------------------------------------------------------------------
startL :: XmlTrees
startL = (lHead "Getting Started") 
      ++ (lList [("Installation", "install")] "")
      ++ (lList
          [ ("Install GHC", "installghc")
          , ("Install Libs", "installlibs")
          , ("Install Hawk", "installhawk")
          , ("Run Example", "runexample")
          ] "1")
      ++ (lList
          [ ("Project Structure", "structure")
          , ("First Steps", "steps")
          ] "")
      ++ (lList
          [ ("Main Application", "mainapp")
          , ("Cabal Package", "cabal")
          , ("Configuration", "config")
          , ("Routing", "routing")
          , ("Controller", "controller")
          , ("Model", "model")
          , ("View", "view")
          , ("Templates", "templates")
          , ("Start it!", "start")
          ] "1")
      ++ (lList' [("FAQ", "/index/faq")] "")

startC :: XmlTrees
startC = [text "start und faq"]

