module App.View.Download where

import App.View.Common

downloadL :: XmlTrees
downloadL = [text ""]

downloadC :: XmlTrees
downloadC = [text "link to hackage, how to install with cabal, download current stable, and current development"]
