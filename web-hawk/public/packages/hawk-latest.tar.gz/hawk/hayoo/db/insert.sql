INSERT INTO `user`(`username`, `password`, `email`, `caseSensitive`, `optimizeQuery`, `wordLimit`, `replace`, `swapChars`, `replacements`, `maxFuzzy`, `modules`, `packages`)
VALUES ('admin', 'admin', NULL, NULL, 'true', 40, 'true', 'true', NULL, 0.9, NULL, NULL);

INSERT INTO `user`(`username`, `password`, `email`, `caseSensitive`, `optimizeQuery`, `wordLimit`, `replace`, `swapChars`, `replacements`, `maxFuzzy`, `modules`, `packages`)
VALUES ('test', 'test', NULL, NULL, 'true', 0, 'false', 'false', NULL, 0.0, 'Data (Text,500)', '');

